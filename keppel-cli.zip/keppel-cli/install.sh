#!/usr/bin/env sh

cp -r keppel-cli /usr/local/bin
ln -sf /usr/local/bin/keppel-cli/bin/keppel-cli /usr/local/bin/keppel